window.LE_JARDIN={"name": "Le Jardin", "subtitle": "Restaurant, Tavern & Banquet Hall", "phoneDisplay": "(847) 361-3103", "phoneHref": "+18473613103", "secondPhoneDisplay": "(708) 831-8137", "secondPhoneHref": "+17088318137", "address": "5532 W Belmont Ave, Chicago, IL 60641", "mapsUrl": "https://www.google.com/maps/search/?api=1&query=5532+W+Belmont+Ave+Chicago+IL+60641", "instagramUrl": "", "facebookUrl": ""};
window.LE_JARDIN_MENU=[
  {
    "category": "Appetizers",
    "name": "Brochettes 3pcs",
    "price": "$12",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Brochettes Shrimps 2pcs",
    "price": "$12",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Buffalo Wings 8pcs",
    "price": "$13",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Beignets / Puff Puff 5pcs",
    "price": "$6",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Grilled Chicken Wings 5pcs",
    "price": "$12",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Museau",
    "price": "$10",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Pastel 4pcs",
    "price": "$12",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Tropical Cuisine Sandwich",
    "price": "$11",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Suya",
    "price": "$12",
    "image": null,
    "description": ""
  },
  {
    "category": "Appetizers",
    "name": "Chin Chin",
    "price": "3 for $10",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Puff Puff & Beans",
    "price": "$11",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Shrimp & Mushroom in White Creaming Sauce",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Poisson Braisé",
    "price": "$23",
    "image": "/assets/images/hero-fish.jpg",
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Poisson Braisé — Red Snapper",
    "price": "$25",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Peanut Butter Soup",
    "price": "$22",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Émincé de Boeuf",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Poulet Braisé",
    "price": "$16",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Tomatoes Stew",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Okra Soup",
    "price": "$23",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Légumes Fricassée",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Poulet à la Moutarde",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "BBQ Ribs",
    "price": "$19",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Curry Chicken",
    "price": "$19",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Pork Braisé",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Ndolé",
    "price": "$23",
    "image": "/assets/images/ndole.jpg",
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Trippes Sauté",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Pepper Soup",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Egusi Soup",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Eru",
    "price": "$23",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Poulet DG",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Tropical Rice Dinner",
    "price": "$12",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Brochettes 6pcs",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Salmon Braisé",
    "price": "$25",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Goat Sauté",
    "price": "$25",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Mbongo Tchobi",
    "price": "$21",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Deluxe Platter",
    "price": "$90",
    "image": null,
    "description": ""
  },
  {
    "category": "Entrées",
    "name": "Shrimp Fried Rice",
    "price": "$15",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Bobolo (Baton)",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Baked Potatoes",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Fried Sweet Plantain",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "French Fries",
    "price": "$3",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Steamed White Rice",
    "price": "$3",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Mac and Cheese",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Steamed Vegetable",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Tropical Rice",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Jollof Rice",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Fufu",
    "price": "$4",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Extra Meat",
    "price": "$6",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Ndolé",
    "price": "$6",
    "image": null,
    "description": ""
  },
  {
    "category": "Sides",
    "name": "Steamed Yam",
    "price": "$6",
    "image": null,
    "description": ""
  },
  {
    "category": "Drinks",
    "name": "Natural Juice",
    "price": "$5",
    "image": null,
    "description": ""
  },
  {
    "category": "Vegan",
    "name": "Ndolé",
    "price": "$18",
    "image": null,
    "description": ""
  },
  {
    "category": "Vegan",
    "name": "Légumes Fricassée",
    "price": "$18",
    "image": null,
    "description": ""
  },
  {
    "category": "Vegan",
    "name": "Peanut Soup",
    "price": "$18",
    "image": null,
    "description": ""
  },
  {
    "category": "Vegan",
    "name": "Okra Soup",
    "price": "$18",
    "image": null,
    "description": ""
  },
  {
    "category": "Vegan",
    "name": "Eru",
    "price": "$18",
    "image": null,
    "description": ""
  },
  {
    "category": "Vegan",
    "name": "Mbongo Tchobi",
    "price": "$18",
    "image": null,
    "description": ""
  },
  {
    "category": "Salad",
    "name": "Garden Salad",
    "price": "$7",
    "image": null,
    "description": ""
  },
  {
    "category": "Salad",
    "name": "Tropical Salad",
    "price": "$12",
    "image": null,
    "description": ""
  }
];